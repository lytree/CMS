using CMS.Web;

var contentRoot = Path.GetDirectoryName(Environment.ProcessPath);
if (string.IsNullOrEmpty(contentRoot) == false)
{
	Environment.CurrentDirectory = contentRoot;
}
var options = new WebApplicationOptions
{
	Args = args,
	ContentRootPath = contentRoot
};

var builder = WebApplication.CreateBuilder(options);

builder.ConfigureServices();
var app = builder.Build();

app.ConfigureApp();

app.Run();